import './assets/index.ts-b530937e.js';
